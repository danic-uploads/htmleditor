﻿Public Class mainForm

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.mainRichTextBox.AutoSize = False
        Me.mainRichTextBox.Height = Me.Size.Height - 98
        Me.mainRichTextBox.Width = Me.Size.Width - 30

        Me.mainTabControl.AutoSize = False
        Me.mainTabControl.Height = Me.Size.Height - 38
        Me.mainTabControl.Width = Me.Size.Width - 11

        Me.previewWebBrowser.AutoSize = False
        Me.previewWebBrowser.Height = Me.Size.Height - 98
        Me.previewWebBrowser.Width = Me.Size.Width - 30

    End Sub

    Private Sub Form1_Resize(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        Me.mainRichTextBox.AutoSize = False
        Me.mainRichTextBox.Height = Me.Size.Height - 98
        Me.mainRichTextBox.Width = Me.Size.Width - 30

        Me.mainTabControl.AutoSize = False
        Me.mainTabControl.Height = Me.Size.Height - 38
        Me.mainTabControl.Width = Me.Size.Width - 11

        Me.previewWebBrowser.AutoSize = False
        Me.previewWebBrowser.Height = Me.Size.Height - 98
        Me.previewWebBrowser.Width = Me.Size.Width - 30

    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyToolStripMenuItem.Click
        mainRichTextBox.Copy()
    End Sub

    Private Sub PasteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PasteToolStripMenuItem.Click
        mainRichTextBox.Paste()
    End Sub

    Private Sub CutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CutToolStripMenuItem.Click
        mainRichTextBox.Cut()
    End Sub

    Private Sub UndoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UndoToolStripMenuItem.Click
        mainRichTextBox.Undo()
    End Sub

    Private Sub RedoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RedoToolStripMenuItem.Click
        mainRichTextBox.Redo()
    End Sub

    Private Sub SelectAllToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SelectAllToolStripMenuItem.Click
        mainRichTextBox.SelectAll()
    End Sub

    Private Sub FontToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FontToolStripMenuItem.Click
        If FontDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            mainRichTextBox.Font = FontDialog1.Font
        End If
    End Sub

    Private Sub ColorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ColorToolStripMenuItem.Click
        If ColorDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            mainRichTextBox.ForeColor = ColorDialog1.Color
        End If
    End Sub

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripMenuItem.Click
        Using O As New OpenFileDialog With {.Filter = "HTML Files|*.html;*.htm"}
            If O.ShowDialog = 1 Then
                Dim openFile As String
                openFile = My.Computer.FileSystem.ReadAllText(O.FileName)
                mainRichTextBox.Text = (openFile)
                pathLabel.Text = O.FileName
            End If
        End Using
    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem.Click

        If pathLabel.Text = "none" Then
            SaveFileDialog1.Filter = "HTML Files|*.html;*.htm"

            If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK _
          Then

                If My.Computer.FileSystem.FileExists(SaveFileDialog1.FileName) Then
                    My.Computer.FileSystem.DeleteFile(SaveFileDialog1.FileName)
                End If

                My.Computer.FileSystem.WriteAllText _
                (SaveFileDialog1.FileName, mainRichTextBox.Text, True)
                pathLabel.Text = SaveFileDialog1.FileName
            End If

        Else
            My.Computer.FileSystem.DeleteFile(pathLabel.Text)
            My.Computer.FileSystem.WriteAllText(pathLabel.Text, mainRichTextBox.Text, True)
        End If

    End Sub

    Private Sub mainRichTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mainRichTextBox.TextChanged
        previewWebBrowser.DocumentText = mainRichTextBox.Text
    End Sub

    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        AboutForm.Show()
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveAsToolStripMenuItem.Click

        SaveFileDialog1.Filter = "HTML Files|*.html;*.htm"
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK _
      Then

            If My.Computer.FileSystem.FileExists(SaveFileDialog1.FileName) Then
                My.Computer.FileSystem.DeleteFile(SaveFileDialog1.FileName)
            End If

            My.Computer.FileSystem.WriteAllText _
            (SaveFileDialog1.FileName, mainRichTextBox.Text, True)
            pathLabel.Text = SaveFileDialog1.FileName

        End If

    End Sub

    Private Sub About_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles About.Click
        AboutForm.Show()
    End Sub

    Private Sub RunToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RunToolStripMenuItem1.Click

        If pathLabel.Text = "none" Then
            SaveFileDialog1.Filter = "HTML Files|*.html;*.htm"
            If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK _
          Then

                If My.Computer.FileSystem.FileExists(SaveFileDialog1.FileName) Then
                    My.Computer.FileSystem.DeleteFile(SaveFileDialog1.FileName)
                End If

                My.Computer.FileSystem.WriteAllText _
                (SaveFileDialog1.FileName, mainRichTextBox.Text, True)
                pathLabel.Text = SaveFileDialog1.FileName
            End If

        Else
            My.Computer.FileSystem.DeleteFile(pathLabel.Text)
            My.Computer.FileSystem.WriteAllText(pathLabel.Text, mainRichTextBox.Text, True)
        End If

        If My.Computer.FileSystem.FileExists(pathLabel.Text) Then
            Process.Start(pathLabel.Text)
        End If

    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

End Class
