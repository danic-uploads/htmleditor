﻿Public Class AboutForm

    Private Sub AboutForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        versionLabel.Text = Application.ProductVersion
    End Sub
End Class