﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AboutForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AboutForm))
        Me.iconPictureBox = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.versionTextLabel = New System.Windows.Forms.Label()
        Me.creatorTextLabel = New System.Windows.Forms.Label()
        Me.creatorLabel = New System.Windows.Forms.Label()
        Me.versionLabel = New System.Windows.Forms.Label()
        CType(Me.iconPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'iconPictureBox
        '
        Me.iconPictureBox.Image = Global.html_editor.My.Resources.Resources.Hechiceroo_Mnemo_Html1
        Me.iconPictureBox.Location = New System.Drawing.Point(12, 12)
        Me.iconPictureBox.Name = "iconPictureBox"
        Me.iconPictureBox.Size = New System.Drawing.Size(76, 80)
        Me.iconPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.iconPictureBox.TabIndex = 0
        Me.iconPictureBox.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(105, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(95, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "HTML-Editor"
        '
        'versionTextLabel
        '
        Me.versionTextLabel.AutoSize = True
        Me.versionTextLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.versionTextLabel.Location = New System.Drawing.Point(105, 40)
        Me.versionTextLabel.Name = "versionTextLabel"
        Me.versionTextLabel.Size = New System.Drawing.Size(52, 13)
        Me.versionTextLabel.TabIndex = 2
        Me.versionTextLabel.Text = "version:"
        '
        'creatorTextLabel
        '
        Me.creatorTextLabel.AutoSize = True
        Me.creatorTextLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.creatorTextLabel.Location = New System.Drawing.Point(105, 68)
        Me.creatorTextLabel.Name = "creatorTextLabel"
        Me.creatorTextLabel.Size = New System.Drawing.Size(52, 13)
        Me.creatorTextLabel.TabIndex = 3
        Me.creatorTextLabel.Text = "Creator:"
        '
        'creatorLabel
        '
        Me.creatorLabel.AutoSize = True
        Me.creatorLabel.Location = New System.Drawing.Point(151, 68)
        Me.creatorLabel.Name = "creatorLabel"
        Me.creatorLabel.Size = New System.Drawing.Size(33, 13)
        Me.creatorLabel.TabIndex = 4
        Me.creatorLabel.Text = "danic"
        '
        'versionLabel
        '
        Me.versionLabel.AutoSize = True
        Me.versionLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.versionLabel.Location = New System.Drawing.Point(151, 40)
        Me.versionLabel.Name = "versionLabel"
        Me.versionLabel.Size = New System.Drawing.Size(22, 13)
        Me.versionLabel.TabIndex = 5
        Me.versionLabel.Text = "1.0"
        '
        'AboutForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(269, 104)
        Me.Controls.Add(Me.versionLabel)
        Me.Controls.Add(Me.creatorLabel)
        Me.Controls.Add(Me.creatorTextLabel)
        Me.Controls.Add(Me.versionTextLabel)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.iconPictureBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "AboutForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "About"
        CType(Me.iconPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents iconPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents versionTextLabel As System.Windows.Forms.Label
    Friend WithEvents creatorTextLabel As System.Windows.Forms.Label
    Friend WithEvents creatorLabel As System.Windows.Forms.Label
    Friend WithEvents versionLabel As System.Windows.Forms.Label
End Class
